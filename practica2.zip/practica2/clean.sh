make clean
rm -Rf CMakeFiles CMakeCache.txt Makefile
